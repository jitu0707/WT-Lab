const http = require("http");
const sum = require("./sum");

const server = http.createServer((req, res) => {
    if (req.url === "/home") {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        const result = sum(10, 20); // Call the `sum` function
        res.end(result.toString()); // Convert the result to a string and send it
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end("404 Not Found");
    }
});

server.listen(3000, () => {
    console.log("Server listening on port 3000!");
});
