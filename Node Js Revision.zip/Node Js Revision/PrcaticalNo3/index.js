const file=require("fs")
file.writeFile("index.txt","Hello Sir This Node Js Text File",()=>{
    console.log("file write successfully...!")
})
file.readFile("index.txt",(e,d)=>{
    console.log(d.toString());
})
file.appendFile("index.txt"," This is append content",()=>{
    console.log("content appended...");
})
file.unlink("index.txt",()=>{
    console.log("file deleted successfully...!")
})