// const http=require("http")
// const obj=http.createServer((req,res)=>{
//    if(req.url=='/home')
//    {
//     console.log("Hello World From Node Js");
//    }
// })
// obj.listen(3000,()=>{
//     console.log("server listen you...!");
// })

// const sum = require('./sum');
// console.log(sum(10, 20)); 
