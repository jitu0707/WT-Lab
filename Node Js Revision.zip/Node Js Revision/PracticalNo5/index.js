const express=require("express")
const path=require("path")
const body=require("body-parser")
const o=require("mysql")
const obj=express();
obj.get("/home",(req,res)=>{
    res.sendFile(path.join(__dirname,"index.html"))
})
obj.get("/submit",(req,res)=>{
    const username=req.query.uname;
    const passw=req.query.pass;
    
    let oj=o.createConnection({
        user:"root",
        port:3307,
        database:"nodejs",
        host:"localhost"
    })
    oj.connect((err)=>{
        if(err)
        {
            console.log("error occure")
        }
        else{
            console.log("ok...ok...")
        }
    })
    const sql="insert into nod values(?,?)";
    const data=[username,passw]

    oj.query(sql,data,(err,data)=>{
        if(err)
        {
            console.log(err)
        }
        else{
            console.log("success")
        }
    })
})
obj.listen(3000,()=>{
    console.log("server listen you...!")
})