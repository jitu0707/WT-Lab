const EventEmitter=require("events")
const obj=new EventEmitter();
obj.once("hello",()=>{
    console.log("Hello Sir...!");
})
obj.on("harshda",()=>{
    console.log("harshada bagh bsdk...!");
})
obj.emit("hello");
obj.emit("harshda")
obj.emit("harshda")
obj.emit("harshda")
obj.emit("hello");